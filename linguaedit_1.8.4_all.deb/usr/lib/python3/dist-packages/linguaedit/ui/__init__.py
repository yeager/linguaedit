"""PySide6 UI components."""
