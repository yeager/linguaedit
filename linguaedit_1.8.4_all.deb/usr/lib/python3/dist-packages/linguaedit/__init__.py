"""LinguaEdit — A Qt6 translation file editor."""

__version__ = "1.8.4"
APP_ID = "se.danielnylander.LinguaEdit"
