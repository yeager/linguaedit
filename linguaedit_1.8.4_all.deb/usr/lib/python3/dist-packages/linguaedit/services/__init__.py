"""Services: linting, translation, spellcheck, GitHub, platforms."""
