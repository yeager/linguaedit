"""Allow running as `python -m linguaedit`."""
from linguaedit.app import main

main()
